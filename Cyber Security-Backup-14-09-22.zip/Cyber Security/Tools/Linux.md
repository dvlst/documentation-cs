## sha1sum
- SHA1 Checksum von Datei anzeigen:

```
sha1sum /path/to/file
```

- Vergleich von mehreren Hashwerten (funktioniert auch mit einem txt welches Hashwerte und entsprechende Paths zu den Files angibt )
```
sha1sum -c file1 file2
```

