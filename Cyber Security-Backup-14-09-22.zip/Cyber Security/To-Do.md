## Hacking Lab
- [ ] Plaso & Timesketch
- [ ] TCP-Traffic untersuchen und Reverse Shell bauen
- [ ] HTTP Header Streams
- [ ] SSL misconfigurations
- [ ] Decrypting SSL/TLS Traffic
- [ ] Extracting C&C commands from HTTP traffic
- [ ] DNS-Tunnel detektieren
- [ ] PCAP-Datei mit Python bearbeiten