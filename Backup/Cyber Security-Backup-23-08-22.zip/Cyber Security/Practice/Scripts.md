# base64_encoder
## Requirements
- Braucht eine "b64.txt" 

## Code
```
####################
# import modules
import base64
####################

# Open a file
file = open('b64.txt',mode='r')

# read all lines at once
flag = file.read()

code = ""

for i in range(0,50):
    code = base64.b64decode(flag)
    flag = code

print(flag)
file.close()

```

# bruteforce_detector


# keylogger


# pcap_anonymizer


# pcap_finder


# port_scanner


# slowloris


# subdomain_finder
## Requirements
- Braucht eine Domain als Paramter
- Braucht eine "subdomain.txt" mit Beispiel-Subdomains

## Code
```
####################
# import modules
import requests
import sys
####################

sub_list = open("subdomain.txt").read()
subdoms = sub_list.splitlines()

for sub in subdoms:
    sub_domains = f"http://{sub}.{sys.argv[1]}"

    try:
        requests.get(sub_domains)

    except requests.ConnectionError:
        pass

    else:
        print("Valid domain: ",sub_domains)
```

# xss_scanner
