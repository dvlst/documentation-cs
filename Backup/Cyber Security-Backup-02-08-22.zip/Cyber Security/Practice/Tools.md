## Network
### Wireshark

### tcpdump

### ngrep

### dnscat2


## Forensic
### Volatility

### plaso

### timesketch

### Memory Dump

### Cyberchef


## Security
### MITRE

### CIS Benchmark


## Monitoring
### inotify

### checkmk

### Prometheus & Grafana